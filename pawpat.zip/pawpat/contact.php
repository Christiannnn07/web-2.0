<?php
require 'auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Contact Us - PAWPAT</title>
  <link rel="stylesheet" href="reset.css" />
  <link rel="stylesheet" href="style.css" />
  
</head>
<body>

  <!-- NAVBAR -->
  <div class="page-content">
    <div class="nav-wrap">
      <div class="bubble active"></div>
      <div class="bubble hover"></div>
      <nav class="nav">
        <img src="images/logo.png" alt="Logo" class="logo">
        <a href="index.php">Home</a>
        <a href="Aboutus.php">About us</a>
        <a href="Adoption.php">Adoption</a>
        <a class="active" href="contact.php">Contact</a>
        <a href="report.php">Report</a>
        <?php if(isset($_SESSION['user_id'])): ?>
          <a href="account.php">Account</a>
          <a href="logout.php" class="logout-btn">Logout</a>
        <?php else: ?>
          <a href="login.php">Login</a>
        <?php endif; ?>
      </nav>
    </div>

    <!-- CONTACT PAGE CONTENT -->
    <div class="newhotline">
      <div class="container">
        <section class="contact-info">
          <h2>Reach Out to Us</h2>
          <p>If you have questions, want to volunteer, or need assistance with an animal in distress, you can contact PAWPAT directly:</p>
          <p><strong>Phone:</strong> <a href="tel:+1234567890">+1 (234) 567-890</a></p>
          <p><strong>Email:</strong> <a href="mailto:contact@pawpat.org">contact@pawpat.org</a></p>
          <p><strong>Address:</strong> 123 Bacolod City, Negros Occidental</p>
        </section>

        <section class="hotlines">
          <h2>Emergency Animal Rescue Hotlines</h2>
          <p>If you encounter an urgent animal situation, please contact the following hotlines immediately:</p>
          <ul>
            <li><strong>Local Animal Control:</strong> <a href="tel:+11234567890">+1 (123) 456-7890</a></li>
            <li><strong>Wildlife Rescue:</strong> <a href="tel:+19876543210">+1 (987) 654-3210</a></li>
            <li><strong>Pet Poison Helpline:</strong> <a href="tel:+18009991234">+1 (800) 999-1234</a></li>
          </ul>
        </section>
      </div>
    </div>
  </div>

<footer>
    <p>&copy; 2026 PAWPAT. All rights reserved.</p>
    <p>Saving paws. Saving hearts.</p>
  </footer>

</body>
</html>
