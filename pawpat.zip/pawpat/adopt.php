<?php
require 'auth.php'; // handles session_start() and login check
require 'db.php';

$user_id = $_SESSION['user_id']; // auth.php ensures this exists

// Handle adoption request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dog_id'])) {
    $dog_id = $_POST['dog_id'];

    // Prevent double adoption for the same dog
    $check = $conn->prepare("SELECT * FROM adoptions WHERE dog_id=? AND status='pending'");
    $check->bind_param("i", $dog_id);
    $check->execute();
    $res = $check->get_result();

    if ($res->num_rows > 0) {
        $error = "Adoption already pending for this dog.";
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO adoptions (dog_id, user_id, adoption_date, status)
             VALUES (?, ?, NOW(), 'pending')"
        );
        $stmt->bind_param("ii", $dog_id, $user_id);
        $stmt->execute();
        $success = "Adoption request submitted!";
    }
}

// Fetch all dogs
$dogs = $conn->query("SELECT * FROM dogs");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Adoption</title>
<link rel="stylesheet" href="reset.css">
<link rel="stylesheet" href="style.css">
<style>
/* adopt page kung pindoton mismo ang adopt me (STYLE) */
.dog-frame-wrapper { max-width: 1200px; margin: 50px auto; }
.dog-frame-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; }
.dog-frame-card { background: rgba(0,0,0,0.7); border-radius: 20px; overflow: hidden; text-align: center; padding-bottom: 20px; color: #fff; box-shadow: 0 0 15px rgba(0,0,0,0.5); }
.dog-frame-box img { width: 100%; height: 200px; object-fit: cover; }
.dog-frame-desc { padding: 15px; font-size: 18px; }
.dog-frame-card form button { padding: 10px 20px; margin-top: 10px; background: linear-gradient(180deg, #844826, #ED952D); border: none; border-radius: 10px; font-size: 16px; color: #000; cursor: pointer; transition: 0.3s; }
.dog-frame-card form button:hover { background: linear-gradient(180deg, #ED952D, #844826); }
.message, .error-message { text-align: center; margin: 20px 0; font-size: 18px; }
.message { color: #4cff4c; }
.error-message { color: #ff4c4c; }
</style>
</head>
<body>

<div class="page-content">
    <!-- Navbar (uniform with homepage) -->
    <div class="nav-wrap">
        <div class="bubble active"></div>
        <div class="bubble hover"></div>
        <nav class="nav">
            <img src="images/logo.png" alt="Logo" class="logo">
            <a href="index.php">Home</a>
            <a href="Aboutus.php">About us</a>
            <a class="active" href="Adoption.php">Adoption</a>
            <a href="#">Maps</a>
            <a href="#">Contact</a>

            <!-- Dynamic navbar links -->
            <?php if(isset($_SESSION['user_id'])): ?>
                <a href="account.php">Account</a>
                <a href="logout.php" class="logout-btn">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
            <?php endif; ?>
        </nav>
    </div>

    <!-- Feedback messages -->
    <?php if(isset($success)) echo "<div class='message'>$success</div>"; ?>
    <?php if(isset($error)) echo "<div class='error-message'>$error</div>"; ?>

    <!-- Dogs Grid -->
    <div class="dog-frame-wrapper">
        <div class="dog-frame-grid">
            <?php while($dog = $dogs->fetch_assoc()): ?>
                <div class="dog-frame-card">
                    <div class="dog-frame-box">
                        <img src="<?php echo htmlspecialchars($dog['image']); ?>" alt="<?php echo htmlspecialchars($dog['name']); ?>">
                    </div>
                    <p class="dog-frame-desc">
                        <strong>Name:</strong> <?php echo htmlspecialchars($dog['name']); ?><br>
                        <?php echo htmlspecialchars($dog['description']); ?>
                    </p>
                    <form method="POST" action="Adoption.php">
                        <input type="hidden" name="dog_id" value="<?php echo $dog['dog_id']; ?>">
                        <button type="submit">Adopt</button>
                    </form>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>

<footer>
    <p>&copy; 2026 PAWPAT. All rights reserved.</p>
    <p>Saving paws. Saving hearts.</p>
</footer>

</body>
</html>