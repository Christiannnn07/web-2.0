<?php
require 'auth.php';
require 'db.php';

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: report.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$location = trim($_POST['location']);
$report_time = $_POST['report_time'];
$description = trim($_POST['description']);

if (empty($location) || empty($report_time) || empty($description)) {
    die("All required fields must be filled.");
}

/* =========================
   IMAGE UPLOAD HANDLING
   ========================= */
$image_path = null;

if (!empty($_FILES['image']['name'])) {
    $upload_dir = "uploads/reports/";

    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    $file_tmp = $_FILES['image']['tmp_name'];
    $file_name = $_FILES['image']['name'];
    $file_size = $_FILES['image']['size'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

    $allowed_exts = ['jpg', 'jpeg', 'png'];

    if (!in_array($file_ext, $allowed_exts)) {
        die("Only JPG, JPEG, and PNG images are allowed.");
    }

    if ($file_size > 5 * 1024 * 1024) {
        die("Image size must be less than 5MB.");
    }

    $new_filename = "report_" . time() . "_" . rand(1000,9999) . "." . $file_ext;
    $image_path = $upload_dir . $new_filename;

    if (!move_uploaded_file($file_tmp, $image_path)) {
        die("Failed to upload image.");
    }
}

/* =========================
   INSERT REPORT
   ========================= */
$stmt = $conn->prepare("
    INSERT INTO reports (user_id, location, report_time, description, image)
    VALUES (?, ?, ?, ?, ?)
");

$stmt->bind_param(
    "issss",
    $user_id,
    $location,
    $report_time,
    $description,
    $image_path
);

if ($stmt->execute()) {
    $report_id = $stmt->insert_id;
    header("Location: report-view.php?id=" . $report_id);
    exit;
} else {
    die("Something went wrong. Please try again.");
}
