<?php
$host = "localhost";      // usually localhost
$user = "root";           // your database username
$pass = "";               // your database password
$dbname = "pawpat"; // CHANGE THIS

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
