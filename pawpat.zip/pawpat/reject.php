<?php
require 'db.php';

$id = $_GET['id'];
$conn->query("UPDATE adoptions SET status='rejected' WHERE adoption_id=$id");

header("Location: admin-adoptions.php");
