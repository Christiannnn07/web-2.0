<?php
require 'auth.php'; // ensures user is logged in
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Report a PAW in Danger</title>

<link rel="stylesheet" href="reset.css">
<link rel="stylesheet" href="style.css">

<style>
/* Report page styling */
.report-container {
    max-width: 650px;
    margin: 50px auto;
    background: rgba(0,0,0,0.7);
    padding: 40px;
    border-radius: 20px;
    color: #fff;
}

.report-container h2 {
    color: #ED952D;
    margin-bottom: 25px;
    text-align: center;
}

.report-container label {
    display: block;
    text-align: left;
    margin: 15px 0 5px;
    font-size: 16px;
}

.report-container input,
.report-container textarea {
    width: 100%;
    padding: 12px;
    border-radius: 8px;
    border: none;
    font-size: 16px;
}

.report-container textarea {
    resize: vertical;
    min-height: 120px;
}

.report-container button {
    margin-top: 25px;
    width: 100%;
    padding: 15px;
    font-size: 18px;
    border: none;
    border-radius: 10px;
    background: linear-gradient(180deg, #844826, #ED952D);
    color: #000;
    cursor: pointer;
    transition: 0.3s;
}

.report-container button:hover {
    background: linear-gradient(180deg, #ED952D, #844826);
}
</style>

</head>
<body>

<div class="page-content">

    <div class="nav-wrap">
        <div class="bubble active"></div>
        <div class="bubble hover"></div>

        <nav class="nav">
            <img src="images/logo.png" alt="Logo" class="logo">
            <a href="index.php">Home</a>
            <a href="Aboutus.php">About us</a>
            <a href="Adoption.php">Adoption</a>
            <a href="contact.php">Contact</a>
            <a href="report.php" class="active">Report</a>
            <a href="account.php">Account</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </nav>
    </div>

    <div class="report-container">
        <h2>Report a PAW in Danger</h2>

        <form action="submit-report.php" method="POST" enctype="multipart/form-data">

            <label for="location">Location</label>
            <input type="text" name="location" id="location" required placeholder="Street, city, landmark">

            <label for="report_time">Date & Time</label>
            <input type="datetime-local" name="report_time" id="report_time" required>

            <label for="description">Description</label>
            <textarea name="description" id="description" required placeholder="Describe the situation..."></textarea>

            <label for="image">Upload Image (optional)</label>
            <input type="file" name="image" id="image" accept="image/*">

            <button type="submit">Submit Report</button>
        </form>
    </div>

</div>

<footer>
    <p>&copy; 2026 PAWPAT. All rights reserved.</p>
    <p>Saving paws. Saving hearts.</p>
</footer>

</body>
</html>
