<?php
session_start();
require 'db.php';

/* ======================
   AUTH CHECK
   ====================== */
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$stmt = $conn->prepare("SELECT is_admin, username FROM users WHERE user_id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user || $user['is_admin'] != 1) {
    die("Access denied. Admins only.");
}

/* ======================
   ADOPTION FILTER
   ====================== */
$filter = $_GET['status'] ?? 'all';
$filter_sql = "";
if (in_array($filter, ['pending', 'approved', 'rejected'])) {
    $filter_sql = "WHERE a.status = '$filter'";
}

/* ======================
   FETCH ADOPTIONS
   ====================== */
$adoptions = $conn->query("
    SELECT a.adoption_id, d.name AS dog_name, u.username, a.status
    FROM adoptions a
    JOIN dogs d ON a.dog_id = d.dog_id
    JOIN users u ON a.user_id = u.user_id
    $filter_sql
    ORDER BY a.status ASC, a.adoption_date DESC
");

/* ======================
   UPDATE REPORT STATUS
   ====================== */
if (isset($_POST['update_report'])) {
    $report_id = (int)$_POST['report_id'];
    $new_status = $_POST['status'];

    if (in_array($new_status, ['pending','reviewed','resolved'])) {
        $stmt = $conn->prepare("UPDATE reports SET status = ? WHERE report_id = ?");
        $stmt->bind_param("si", $new_status, $report_id);
        $stmt->execute();
    }
}

/* ======================
   FETCH REPORTS
   ====================== */
$reports = $conn->query("
    SELECT r.report_id, r.location, r.report_time, r.status, r.image, u.username
    FROM reports r
    JOIN users u ON r.user_id = u.user_id
    ORDER BY r.report_time DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel</title>

<link rel="stylesheet" href="reset.css">
<link rel="stylesheet" href="style.css">

<style>
/* ADMIN */
.admin-container {
    max-width: 1000px;
    margin: 50px auto;
    background: rgba(0,0,0,0.7);
    padding: 30px;
    border-radius: 20px;
    color: #fff;
}
h2 {
    text-align: center;
    color: #ED952D;
    margin-bottom: 20px;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 40px;
    background: rgba(255,255,255,0.05);
    border-radius: 10px;
    overflow: hidden;
}
th, td {
    padding: 12px;
    border-bottom: 1px solid rgba(255,255,255,0.2);
    font-size: 16px;
    text-align: left;
}
th {
    color: #ED952D;
}
tr:hover {
    background: rgba(237,149,45,0.1);
}
.action-btn {
    padding: 8px 15px;
    border-radius: 10px;
    border: none;
    font-size: 14px;
    font-weight: 500;
    text-decoration: none;
    cursor: pointer;
    transition: 0.3s;
    color: #000;
}

/* COLORS */
.action-btn.approve {
    background: linear-gradient(180deg, #844826, #ED952D);
}
.action-btn.approve:hover {
    background: linear-gradient(180deg, #ED952D, #844826);
}
.action-btn.reject {
    background: linear-gradient(180deg, #ED952D, #844826);
}
.action-btn.reject:hover {
    background: linear-gradient(180deg, #844826, #ED952D);
}

/* REPORT BUTTONS */
.action-btn.report-save {
    background: linear-gradient(180deg, #ED952D, #844826);
}
.action-btn.report-save:hover {
    background: linear-gradient(180deg, #844826, #ED952D);
}

img {
    max-width: 80px;
    border-radius: 8px;
}

@media(max-width: 600px) {
    th, td { font-size: 14px; padding: 8px; }
    .action-btn { font-size: 12px; padding: 6px 12px; }
}
</style>
</head>

<body>
<div class="page-content">

<!-- NAVBAR -->

<div class="nav-wrap">
    <div class="bubble active"></div>
    <div class="bubble hover"></div>
    <nav class="nav">
        <a href="index.php">Home</a>
        <a href="Aboutus.php">About us</a>
        <a href="Adoption.php">Adoption</a>
        <a href="contact.php">Contact</a>
        <?php if (isset($_SESSION['user_id'])): ?>
            <?php if ($user['is_admin'] == 1): ?>
                <a class="active" href="admin-adoptions.php">Admin</a>
            <?php endif; ?>
            <a href="account.php">Account</a>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
        <?php endif; ?>
    </nav>
</div>

<div class="admin-container">

<!-- ADOPTIONS -->

<h2>Adoption Requests</h2>

<form method="GET" class="filter-form">
    <select name="status">
        <option value="all" <?= $filter=='all'?'selected':'' ?>>All</option>
        <option value="pending" <?= $filter=='pending'?'selected':'' ?>>Pending</option>
        <option value="approved" <?= $filter=='approved'?'selected':'' ?>>Approved</option>
        <option value="rejected" <?= $filter=='rejected'?'selected':'' ?>>Rejected</option>
    </select>
    <button class="action-btn">Filter</button>
</form>

<table>
<tr>
    <th>Dog</th>
    <th>User</th>
    <th>Status</th>
    <th>Action</th>
</tr>
<?php while ($a = $adoptions->fetch_assoc()): ?>
<tr>
    <td><?= htmlspecialchars($a['dog_name']); ?></td>
    <td><?= htmlspecialchars($a['username']); ?></td>
    <td><?= ucfirst($a['status']); ?></td>
    <td>
        <a class="action-btn approve" href="approve.php?id=<?= $a['adoption_id']; ?>">Approve</a>
        <a class="action-btn reject" href="reject.php?id=<?= $a['adoption_id']; ?>">Reject</a>
    </td>
</tr>
<?php endwhile; ?>
</table>

<!-- REPORTS -->
 
<h2>Dog Danger Reports</h2>

<table>
<tr>
    <th>User</th>
    <th>Location</th>
    <th>Date</th>
    <th>Image</th>
    <th>Status</th>
    <th>Update</th>
</tr>

<?php while ($r = $reports->fetch_assoc()): ?>
<tr>
    <td><?= htmlspecialchars($r['username']); ?></td>
    <td><?= htmlspecialchars($r['location']); ?></td>
    <td><?= date("F j, Y", strtotime($r['report_time'])); ?></td>
    <td>
        <?php if ($r['image']): ?>
            <img src="<?= htmlspecialchars($r['image']); ?>">
        <?php else: ?>
            —
        <?php endif; ?>
    </td>
    <td><?= ucfirst($r['status']); ?></td>
    <td>
        <form method="POST">
            <input type="hidden" name="report_id" value="<?= $r['report_id']; ?>">
            <select name="status">
                <option value="pending" <?= $r['status']=='pending'?'selected':'' ?>>Pending</option>
                <option value="reviewed" <?= $r['status']=='reviewed'?'selected':'' ?>>Reviewed</option>
                <option value="resolved" <?= $r['status']=='resolved'?'selected':'' ?>>Resolved</option>
            </select>
            <button class="action-btn report-save" name="update_report">Save</button>
        </form>
    </td>
</tr>
<?php endwhile; ?>
</table>

</div>
</div>

<footer>
<p>&copy; 2026 PAWPAT. All rights reserved.</p>
<p>Saving paws. Saving hearts.</p>
</footer>

</body>
</html>
