<?php
require 'auth.php';
require 'db.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid report.");
}

$report_id = (int) $_GET['id'];
$user_id = $_SESSION['user_id'];

/* Fetch report and ensure it belongs to the logged-in user */
$stmt = $conn->prepare("
    SELECT r.*, u.username
    FROM reports r
    JOIN users u ON r.user_id = u.user_id
    WHERE r.report_id = ? AND r.user_id = ?
");
$stmt->bind_param("ii", $report_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Report not found or access denied.");
}

$report = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Report Details</title>

<link rel="stylesheet" href="reset.css">
<link rel="stylesheet" href="style.css">

<style>
.report-view-container {
    max-width: 700px;
    margin: 50px auto;
    background: rgba(0,0,0,0.7);
    padding: 40px;
    border-radius: 20px;
    color: #fff;
}

.report-view-container h2 {
    color: #ED952D;
    text-align: center;
    margin-bottom: 20px;
}

.report-item {
    margin: 15px 0;
    font-size: 18px;
}

.report-item strong {
    color: #ED952D;
}

.report-image {
    margin-top: 25px;
    text-align: center;
}

.report-image img {
    max-width: 100%;
    border-radius: 12px;
}

.status {
    display: inline-block;
    padding: 8px 15px;
    border-radius: 20px;
    font-size: 14px;
    margin-top: 10px;
}

.status-pending {
    background: #ED952D;
    color: #000;
}

.status-reviewed {
    background: #3498db;
}

.status-resolved {
    background: #2ecc71;
}
</style>
</head>

<body>

<div class="page-content">

    <div class="nav-wrap">
        <div class="bubble active"></div>
        <div class="bubble hover"></div>

        <nav class="nav">
            <a href="index.php">Home</a>
            <a href="Adoption.php">Adoption</a>
            <a href="report.php">Report</a>
            <a href="account.php">Account</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </nav>
    </div>

    <div class="report-view-container">
        <h2>Report Submitted Successfully</h2>

        <div class="report-item">
            <strong>Reported by:</strong>
            <?= htmlspecialchars($report['username']); ?>
        </div>

        <div class="report-item">
            <strong>Location:</strong>
            <?= htmlspecialchars($report['location']); ?>
        </div>

        <div class="report-item">
            <strong>Date & Time:</strong>
            <?= date("F j, Y · g:i A", strtotime($report['report_time'])); ?>
        </div>

        <div class="report-item">
            <strong>Description:</strong><br>
            <?= nl2br(htmlspecialchars($report['description'])); ?>
        </div>

        <div class="report-item">
            <strong>Status:</strong>
            <span class="status status-<?= htmlspecialchars($report['status']); ?>">
                <?= ucfirst($report['status']); ?>
            </span>
        </div>

        <?php if (!empty($report['image'])): ?>
            <div class="report-image">
                <img src="<?= htmlspecialchars($report['image']); ?>" alt="Reported dog image">
            </div>
        <?php endif; ?>
    </div>

</div>

<footer>
    <p>&copy; 2026 PAWPAT. All rights reserved.</p>
    <p>Saving paws. Saving hearts.</p>
</footer>

</body>
</html>
