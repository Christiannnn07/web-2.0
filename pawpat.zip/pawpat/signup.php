<?php
session_start();
require 'db.php'; // Your database connection

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $contact = trim($_POST['contact'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');

    // Basic validation
    if ($password !== $confirm_password) {
        $error = "Passwords do not match!";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email address!";
    } elseif (!preg_match('/^[0-9]{10,15}$/', $contact)) {
        $error = "Contact number must be 10-15 digits!";
    } else {
        // Check if username or email exists
        $stmt = $conn->prepare("SELECT * FROM users WHERE username=? OR email=?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Username or email already exists!";
        } else {
            // Insert new user
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, email, contact, password) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $username, $email, $contact, $hashed_password);
            if ($stmt->execute()) {
                $success = "Account created successfully! You can <a href='login.php'>login now</a>.";
            } else {
                $error = "Database error. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign Up</title>
<link rel="stylesheet" href="reset.css">
<link rel="stylesheet" href="style.css">
</head>

<body>

<div class="page-content">
    <div class="nav-wrap">
        <div class="bubble active"></div>
        <div class="bubble hover"></div>
        <nav class="nav">
            <img src="images/logo.png" alt="Logo" class="logo">
            <a href="index.php">Home</a>
            <a href="Aboutus.php">About us</a>
            <a href="Adoption.php">Adoption</a>
            <a href="#">Maps</a>
            <a href="#">Contact</a>
            <a href="login.php">Login</a>
            <a class="active" href="signup.php">Signup</a>
        </nav>
    </div>

    <div class="signup-container">
        <h2>Sign Up</h2>
        <?php if($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if($success): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        <form method="POST" action="signup.php">
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="contact" placeholder="Contact Number" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <button type="submit">Sign Up</button>
        </form>
        <div class="signup-links">
            <p>Already have an account? <a href="login.php">Login here</a></p>
        </div>
    </div>
</div>

<footer>
    <p>&copy; 2026 PAWPAT. All rights reserved.</p>
    <p>Saving paws. Saving hearts.</p>
</footer>

</body>
</html>
