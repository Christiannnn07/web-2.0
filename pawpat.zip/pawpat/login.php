<?php
session_start();
require 'db.php'; // Your database connection

// If the user is already logged in, redirect immediately
if (isset($_SESSION['user_id'])) {
    header("Location: Adoption.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM users WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        // Regenerate session ID for security
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['username'] = $user['username'];

        // Redirect immediately after login
        header("Location: Adoption.php");
        exit;
    } else {
        $error = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<link rel="stylesheet" href="reset.css">
<link rel="stylesheet" href="style.css">
<style>
    /* Login page specific styles */
    .login-container {
        max-width: 400px;
        margin: 50px auto;
        background: rgba(0,0,0,0.7);
        padding: 40px;
        border-radius: 20px;
        box-shadow: 0 0 15px rgba(0,0,0,0.5);
        color: #fff;
    }
    .login-container h2 {
        text-align: center;
        margin-bottom: 30px;
        color: #ED952D;
    }
    .login-container input {
        width: 100%;
        padding: 15px;
        margin: 10px 0;
        border-radius: 10px;
        border: none;
        font-size: 18px;
    }
    .login-container button {
        width: 100%;
        padding: 15px;
        margin-top: 20px;
        background: linear-gradient(180deg, #844826, #ED952D);
        border: none;
        border-radius: 10px;
        font-size: 18px;
        color: #000;
        cursor: pointer;
        transition: 0.3s;
    }
    .login-container button:hover {
        background: linear-gradient(180deg, #ED952D, #844826);
    }
    .error {
        color: #ff4c4c;
        text-align: center;
        margin-bottom: 15px;
    }
    .login-links {
        text-align: center;
        margin-top: 20px;
    }
    .login-links a {
        color: #ED952D;
        text-decoration: none;
    }
    .login-links a:hover {
        text-decoration: underline;
    }
</style>
</head>
<body>

<div class="page-content">
    <div class="nav-wrap">
        <div class="bubble active"></div>
        <div class="bubble hover"></div>
        <nav class="nav">
            <img src="images/logo.png" alt="Logo" class="logo">
            <a href="index.php">Home</a>
            <a href="Aboutus.php">About us</a>
            <a href="Adoption.php">Adoption</a>
            <a href="#">Maps</a>
            <a href="#">Contact</a>
            <a class="active" href="login.php">Login</a>
            <a href="#">Signup</a>
        </nav>
    </div>

    <div class="login-container">
        <h2>Login</h2>
        <?php if($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        <form method="POST" action="login.php">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required autocomplete="off">
            <button type="submit">Login</button>
        </form>
        <div class="login-links">
            <p>Don't have an account? <a href="signup.php">Sign up</a></p>
        </div>
    </div>
</div>

<footer>
    <p>&copy; 2026 PAWPAT. All rights reserved.</p>
    <p>Saving paws. Saving hearts.</p>
</footer>

</body>
</html>
