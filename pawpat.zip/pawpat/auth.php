<?php
session_start();

// If user is logged in, hide the login page
$currentPage = basename($_SERVER['PHP_SELF']); 

if (isset($_SESSION['user_id']) && $currentPage == 'login.php') {
    header("Location: Adoption.php");
    exit;
}


if (!isset($_SESSION['user_id']) && $currentPage != 'login.php' && $currentPage != 'signup.php') {
    header("Location: login.php");
    exit;
}
?>
