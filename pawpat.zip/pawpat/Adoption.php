<?php
require 'auth.php';
require 'db.php';

// get all dogs from database
$result = $conn->query("SELECT * FROM dogs");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Adoption</title>

  <link rel="stylesheet" href="reset.css" />
  <link rel="stylesheet" href="style.css" />
</head>

<body>

<div class="page-content">

  <!-- ===== NAVBAR ===== -->
  <div class="nav-wrap">
    <div class="bubble active"></div>
    <div class="bubble hover"></div>

    <nav class="nav">
      <img src="images/logo.png" alt="Logo" class="logo">

      <a href="index.php">Home</a>
      <a href="Aboutus.php">About us</a>
      <a class="active" href="Adoption.php">Adoption</a>
      <a href="contact.php">Contact</a>
      <a href="report.php">Report</a>

      <!-- Dynamic navbar -->
      <?php if (isset($_SESSION['user_id'])): ?>
        <a href="account.php">Account</a>
        <a href="logout.php" class="logout-btn">Logout</a>
      <?php else: ?>
        <a href="login.php">Login</a>
      <?php endif; ?>
    </nav>
  </div>

  <!-- ===== ADOPTION DOG CARDS ===== -->
  <div class="dog-frame-wrapper">
    <div class="dog-frame-grid">

      <?php while ($dog = $result->fetch_assoc()): ?>
        <div class="dog-frame-card">

          <div class="dog-frame-box">
            <img src="<?= htmlspecialchars($dog['image']); ?>" 
                 alt="<?= htmlspecialchars($dog['name']); ?>">
          </div>

          <p class="dog-frame-desc">
            <strong><?= strtoupper(htmlspecialchars($dog['name'])); ?></strong><br>
            <?= htmlspecialchars($dog['description']); ?>
          </p>

          <?php if ($dog['status'] === 'available'): ?>
            <form method="POST" action="adopt.php">
              <input type="hidden" name="dog_id" value="<?= $dog['dog_id']; ?>">
              <button type="submit" class="dog-frame-btn">
                Adopt Me
              </button>
            </form>
          <?php else: ?>
            <button class="dog-frame-btn" disabled>
              Already Adopted
            </button>
          <?php endif; ?>

        </div>
      <?php endwhile; ?>

    </div>
  </div>

</div>

<!-- ===== FOOTER ===== -->
<footer>
  <p>&copy; 2026 PAWPAT. All rights reserved.</p>
  <p>Saving paws. Saving hearts.</p>
</footer>

</body>
</html>
