<?php
require 'auth.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Home</title>
    <link rel="stylesheet" href="reset.css" />
    <link rel="stylesheet" href="style.css" />
  </head>

  <body>
  <div class="page-content">
    <div class="nav-wrap">
      <div class="bubble active"></div>
      <div class="bubble hover"></div>
      <nav class="nav">
        <img src="images/logo.png" alt="Logo" class="logo">
        <a class="active" href="index.php">Home</a>
        <a href="Aboutus.php">About us</a>
        <a href="Adoption.php">Adoption</a>
        <a href="contact.php">Contact</a>
        <a href="report.php">Report</a>
        
        <!-- Dynamic navbar links -->
        <?php if(isset($_SESSION['user_id'])): ?>
          <a href="account.php">Account</a>
          <a href="logout.php" class="logout-btn">Logout</a>
        <?php else: ?>
          <a href="login.php">Login</a>
        <?php endif; ?>
      </nav>
    </div>

  <div class="hero">
  <div class="slideshowhomepage">
    <img src="images/dog1.jpg" alt="Dog 1">
    <img src="images/dog2.jpg" alt="Dog 2">
    <img src="images/dog3.jpg" alt="Dog 3">
  </div>

  <div class="hero-text">
    <h1>A RESCUED PAW</h1>
    <h2>IS A HEART SAVED</h2>
  </div>
</div>

<!-- Adopt Now Button BELOW hero -->
<div class="hero-button">
  <a href="Adoption.php" class="adopt-now-btn">ADOPT NOW</a>
</div>
    

  </div>

  <footer>
    <p>&copy; 2026 PAWPAT. All rights reserved.</p>
    <p>Saving paws. Saving hearts.</p>
  </footer>
  </body>
</html>
