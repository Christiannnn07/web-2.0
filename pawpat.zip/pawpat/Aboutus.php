<?php
require 'auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | PAWPAT</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>

<div class="hero-wrapper">

  <div class="nav-wrap">
    <div class="bubble active"></div>
    <div class="bubble hover"></div>

    <nav class="nav">
      <img src="images/logo.png" alt="Logo" class="logo">

      <a href="index.php">Home</a>
      <a class="active" href="Aboutus.php">About us</a>
      <a href="Adoption.php">Adoption</a>
      <a href="contact.php">Contact</a>
      <a href="report.php">Report</a>

      <!-- Dynamic navbar links -->
      <?php if (isset($_SESSION['user_id'])): ?>
        <a href="account.php">Account</a>
        <a href="logout.php" class="logout-btn">Logout</a>
      <?php else: ?>
        <a href="login.php">Login</a>
      <?php endif; ?>
    </nav>
  </div>

  <div class="top-quote">
    <div class="slideshow">
      <img src="images/slide1.jpg" class="slide active">
      <img src="images/slide2.jpg" class="slide">
      <img src="images/slide3.jpg" class="slide">
    </div>

    <span class="main-quote">A RESCUED PAW IS A HEART SAVED</span>

    <h1 class="about-title">About PAWPAT</h1>
    <h2 class="about-subtitle">
      A community-driven initiative dedicated to saving lives, one paw at a time.
    </h2>
  </div>

</div>

<div class="pawpat-about">
  <div class="container">

    <section class="section">
      <h2>Who We Are</h2>
      <p>
        PAWPAT is a community-driven initiative dedicated to saving, protecting,
        and giving a second chance to stray, abandoned, and mistreated dogs and cats.
      </p>
    </section>

    <div class="quote">“A rescued paw is a heart saved.”</div>

    <section class="section">
      <h2>Why PAWPAT Exists</h2>
      <p>
        PAWPAT was created to address the lack of a centralized and accessible
        system for animal rescue, rehabilitation, and adoption.
      </p>
      <p>
        It connects communities, rescuers, shelters, and adopters in one place.
      </p>
    </section>

    <section class="section">
      <h2>What We Do</h2>
      <div class="features">
        <div class="feature-box">
          <h3>Report & Rescue</h3>
          <p>Report stray or injured animals and connect them with nearby rescuers.</p>
        </div>
        <div class="feature-box">
          <h3>Find Shelters</h3>
          <p>Locate rescue groups and shelter centers easily.</p>
        </div>
        <div class="feature-box">
          <h3>Adopt a Friend</h3>
          <p>Find loving homes for adoptable pets.</p>
        </div>
        <div class="feature-box">
          <h3>Support the Cause</h3>
          <p>Donate to help fund rescues and medical care.</p>
        </div>
      </div>
    </section>

    <section class="section">
      <h2>Our Impact</h2>
      <p>
        PAWPAT improves animal welfare, promotes safer streets,
        and builds a more compassionate community.
      </p>
    </section>

  </div>

  <footer>
    <p>&copy; 2026 PAWPAT. All rights reserved.</p>
    <p>Saving paws. Saving hearts.</p>
  </footer>
</div>

<script>
  const slides = document.querySelectorAll(".slide");
  let index = 0;

  setInterval(() => {
    slides[index].classList.remove("active");
    index = (index + 1) % slides.length;
    slides[index].classList.add("active");
  }, 4000);
</script>

</body>
</html>
