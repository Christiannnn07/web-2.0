<?php
require 'auth.php';
require 'db.php';

/* ======================
   USER INFO
   ====================== */
$stmt = $conn->prepare("SELECT username, email, contact FROM users WHERE user_id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

/* ======================
   ADOPTION REQUESTS
   ====================== */
$requests_stmt = $conn->prepare("
    SELECT a.adoption_id, d.name AS dog_name, a.status, a.adoption_date
    FROM adoptions a
    JOIN dogs d ON a.dog_id = d.dog_id
    WHERE a.user_id = ?
    ORDER BY a.adoption_date DESC
");
$requests_stmt->bind_param("i", $_SESSION['user_id']);
$requests_stmt->execute();
$requests = $requests_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

/* ======================
   USER REPORTS
   ====================== */
$reports_stmt = $conn->prepare("
    SELECT report_id, location, report_time, status
    FROM reports
    WHERE user_id = ?
    ORDER BY created_at DESC
");
$reports_stmt->bind_param("i", $_SESSION['user_id']);
$reports_stmt->execute();
$reports = $reports_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Account</title>

<link rel="stylesheet" href="reset.css">
<link rel="stylesheet" href="style.css">

<style>
.requests-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    color: #fff;
}

.requests-table th,
.requests-table td {
    padding: 12px;
    border-bottom: 1px solid rgba(255,255,255,0.2);
    text-align: center;
}

.requests-table th {
    color: #ED952D;
}

.status-pending { color: #ED952D; }
.status-approved { color: #2ecc71; }
.status-rejected { color: #e74c3c; }
.status-reviewed { color: #3498db; }
.status-resolved { color: #2ecc71; }

.view-link {
    color: #ED952D;
    text-decoration: underline;
}
</style>

</head>
<body>

<div class="page-content">

    <div class="nav-wrap">
        <div class="bubble active"></div>
        <div class="bubble hover"></div>

        <nav class="nav">
            <a href="index.php">Home</a>
            <a href="Aboutus.php">About us</a>
            <a href="Adoption.php">Adoption</a>
            <a href="contact.php">Contact</a>
            <a href="report.php">Report</a>
            <a href="account.php" class="active">Account</a>
            <a href="admin-adoptions.php">Admin</a>
            <a href="logout.php" class="logout-btn">Logout</a>
        </nav>
    </div>

    <div class="account-container">
        <h2>Hello, <?= htmlspecialchars($user['username']); ?>!</h2>

        <p><strong>Email:</strong> <?= htmlspecialchars($user['email']); ?></p>
        <p><strong>Contact Number:</strong> <?= htmlspecialchars($user['contact']); ?></p>

        <!-- ======================
             ADOPTION REQUESTS
             ====================== -->
        <h3>Your Adoption Requests</h3>

        <?php if (count($requests) > 0): ?>
            <table class="requests-table">
                <thead>
                    <tr>
                        <th>Dog</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requests as $req): ?>
                        <tr>
                            <td><?= htmlspecialchars($req['dog_name']); ?></td>
                            <td class="status-<?= strtolower($req['status']); ?>">
                                <?= ucfirst($req['status']); ?>
                            </td>
                            <td><?= date("F j, Y", strtotime($req['adoption_date'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>You have not made any adoption requests yet.</p>
        <?php endif; ?>

        <!-- ======================
             USER REPORTS
             ====================== -->
        <h3 style="margin-top:40px;">My Reports</h3>

        <?php if (count($reports) > 0): ?>
            <table class="requests-table">
                <thead>
                    <tr>
                        <th>Location</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>View</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reports as $rep): ?>
                        <tr>
                            <td><?= htmlspecialchars($rep['location']); ?></td>
                            <td><?= date("F j, Y", strtotime($rep['report_time'])); ?></td>
                            <td class="status-<?= strtolower($rep['status']); ?>">
                                <?= ucfirst($rep['status']); ?>
                            </td>
                            <td>
                                <a class="view-link" href="report-view.php?id=<?= $rep['report_id']; ?>">
                                    View
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>You have not submitted any reports yet.</p>
        <?php endif; ?>

        <a class="logout-btn" href="logout.php">Logout</a>
    </div>

</div>

<footer>
    <p>&copy; 2026 PAWPAT. All rights reserved.</p>
    <p>Saving paws. Saving hearts.</p>
</footer>

</body>
</html>
